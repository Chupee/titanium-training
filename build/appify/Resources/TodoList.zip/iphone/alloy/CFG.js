module.exports = {
    dependencies: {
        "com.orthlieb.navigationgroup": "*"
    }
};